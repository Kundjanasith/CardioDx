# CardioTwin-AI v3.3.3 Calibration + Threshold Stress Test

Created: 2026-05-24T21:14:50.276749+00:00

## Purpose

Analyze threshold trade-offs after v3.3.2 source-separated validation.

## Key Interpretation

- Screening thresholds prioritize sensitivity.
- Lower specificity and precision are expected under screening mode.
- Threshold stress does not change the frozen model/runtime.
- Final clinical thresholds require prospective doctor-reviewed validation.

## Outputs

- artifacts\public_multicenter_validation_v33\public_threshold_stress_curve_v333.csv
- artifacts\public_multicenter_validation_v33\public_threshold_stress_picks_v333.json
- artifacts\public_multicenter_validation_v33\public_calibration_threshold_summary_v333.json

## Compact Threshold Recommendations

{
  "cpsc_2018": {
    "NORM": {
      "best_f1": {
        "threshold": 0.73,
        "f1": 0.7111111111111111,
        "sensitivity": 0.8533333333333334,
        "specificity": 0.7239057239057239,
        "precision": 0.6095238095238096,
        "positives": 300,
        "negatives": 594
      },
      "best_youden": {
        "threshold": 0.7,
        "f1": 0.7108108108108108,
        "sensitivity": 0.8766666666666667,
        "specificity": 0.702020202020202,
        "precision": 0.5977272727272728,
        "positives": 300,
        "negatives": 594
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.63,
        "f1": 0.6994818652849741,
        "sensitivity": 0.9,
        "specificity": 0.6599326599326599,
        "precision": 0.5720338983050848,
        "positives": 300,
        "negatives": 594
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.35000000000000003,
        "f1": 0.662020905923345,
        "sensitivity": 0.95,
        "specificity": 0.5353535353535354,
        "precision": 0.5080213903743316,
        "positives": 300,
        "negatives": 594
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.8447572302818298,
        "f1": 0.7,
        "sensitivity": 0.7466666666666667,
        "specificity": 0.8047138047138047,
        "precision": 0.6588235294117647,
        "positives": 300,
        "negatives": 594
      }
    },
    "MI": {
      "best_f1": null,
      "best_youden": null,
      "best_sensitivity_90_with_max_specificity": null,
      "best_sensitivity_95_with_max_specificity": null,
      "best_specificity_80_with_max_sensitivity": null
    },
    "STTC": {
      "best_f1": {
        "threshold": 0.019626392051577544,
        "f1": 0.5933014354066986,
        "sensitivity": 0.8266666666666667,
        "specificity": 0.5151515151515151,
        "precision": 0.4626865671641791,
        "positives": 300,
        "negatives": 594
      },
      "best_youden": {
        "threshold": 0.026461102589964796,
        "f1": 0.5917602996254682,
        "sensitivity": 0.79,
        "specificity": 0.5555555555555556,
        "precision": 0.47305389221556887,
        "positives": 300,
        "negatives": 594
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.0052111192978918025,
        "f1": 0.5639958376690947,
        "sensitivity": 0.9033333333333333,
        "specificity": 0.3434343434343434,
        "precision": 0.40998487140695916,
        "positives": 300,
        "negatives": 594
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.0016969353170133642,
        "f1": 0.5337078651685393,
        "sensitivity": 0.95,
        "specificity": 0.18686868686868688,
        "precision": 0.37109375,
        "positives": 300,
        "negatives": 594
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.18229634076356893,
        "f1": 0.5116279069767442,
        "sensitivity": 0.4766666666666667,
        "specificity": 0.8047138047138047,
        "precision": 0.5521235521235521,
        "positives": 300,
        "negatives": 594
      }
    },
    "CD": {
      "best_f1": {
        "threshold": 0.45,
        "f1": 0.8327974276527331,
        "sensitivity": 0.8327974276527331,
        "specificity": 0.9108061749571184,
        "precision": 0.8327974276527331,
        "positives": 311,
        "negatives": 583
      },
      "best_youden": {
        "threshold": 0.45,
        "f1": 0.8327974276527331,
        "sensitivity": 0.8327974276527331,
        "specificity": 0.9108061749571184,
        "precision": 0.8327974276527331,
        "positives": 311,
        "negatives": 583
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.28,
        "f1": 0.8115942028985508,
        "sensitivity": 0.9003215434083601,
        "specificity": 0.8301886792452831,
        "precision": 0.7387862796833773,
        "positives": 311,
        "negatives": 583
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.13,
        "f1": 0.7279411764705882,
        "sensitivity": 0.954983922829582,
        "specificity": 0.6432246998284734,
        "precision": 0.5881188118811881,
        "positives": 311,
        "negatives": 583
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.27,
        "f1": 0.810966810966811,
        "sensitivity": 0.9035369774919614,
        "specificity": 0.8267581475128645,
        "precision": 0.7356020942408377,
        "positives": 311,
        "negatives": 583
      }
    },
    "HYP": {
      "best_f1": null,
      "best_youden": null,
      "best_sensitivity_90_with_max_specificity": null,
      "best_sensitivity_95_with_max_specificity": null,
      "best_specificity_80_with_max_sensitivity": null
    }
  },
  "cpsc_2018_extra": {
    "NORM": {
      "best_f1": {
        "threshold": 0.62,
        "f1": 0.035398230088495575,
        "sensitivity": 1.0,
        "specificity": 0.8850210970464135,
        "precision": 0.018018018018018018,
        "positives": 2,
        "negatives": 948
      },
      "best_youden": {
        "threshold": 0.62,
        "f1": 0.035398230088495575,
        "sensitivity": 1.0,
        "specificity": 0.8850210970464135,
        "precision": 0.018018018018018018,
        "positives": 2,
        "negatives": 948
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.62,
        "f1": 0.035398230088495575,
        "sensitivity": 1.0,
        "specificity": 0.8850210970464135,
        "precision": 0.018018018018018018,
        "positives": 2,
        "negatives": 948
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.62,
        "f1": 0.035398230088495575,
        "sensitivity": 1.0,
        "specificity": 0.8850210970464135,
        "precision": 0.018018018018018018,
        "positives": 2,
        "negatives": 948
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.62,
        "f1": 0.035398230088495575,
        "sensitivity": 1.0,
        "specificity": 0.8850210970464135,
        "precision": 0.018018018018018018,
        "positives": 2,
        "negatives": 948
      }
    },
    "MI": {
      "best_f1": {
        "threshold": 0.36000000000000004,
        "f1": 0.7394167450611477,
        "sensitivity": 0.841541755888651,
        "specificity": 0.5797101449275363,
        "precision": 0.6593959731543624,
        "positives": 467,
        "negatives": 483
      },
      "best_youden": {
        "threshold": 0.62,
        "f1": 0.7294372294372294,
        "sensitivity": 0.721627408993576,
        "specificity": 0.7515527950310559,
        "precision": 0.737417943107221,
        "positives": 467,
        "negatives": 483
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.23429078117012975,
        "f1": 0.7293103448275862,
        "sensitivity": 0.9057815845824411,
        "specificity": 0.4409937888198758,
        "precision": 0.6103896103896104,
        "positives": 467,
        "negatives": 483
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.13,
        "f1": 0.7041139240506329,
        "sensitivity": 0.9528907922912205,
        "specificity": 0.2712215320910973,
        "precision": 0.5583437892095358,
        "positives": 467,
        "negatives": 483
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.7100000000000001,
        "f1": 0.7088607594936709,
        "sensitivity": 0.6595289079229122,
        "specificity": 0.8053830227743272,
        "precision": 0.7661691542288557,
        "positives": 467,
        "negatives": 483
      }
    },
    "STTC": {
      "best_f1": {
        "threshold": 0.005173264909535605,
        "f1": 0.7803583278035833,
        "sensitivity": 0.971900826446281,
        "specificity": 0.08985507246376812,
        "precision": 0.6518847006651884,
        "positives": 605,
        "negatives": 345
      },
      "best_youden": {
        "threshold": 0.48000000000000004,
        "f1": 0.6931818181818182,
        "sensitivity": 0.6049586776859505,
        "specificity": 0.7536231884057971,
        "precision": 0.811529933481153,
        "positives": 605,
        "negatives": 345
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.026552574560046182,
        "f1": 0.7783321454027085,
        "sensitivity": 0.9024793388429752,
        "specificity": 0.26956521739130435,
        "precision": 0.6842105263157895,
        "positives": 605,
        "negatives": 345
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.008947826400399185,
        "f1": 0.7789046653144016,
        "sensitivity": 0.9520661157024793,
        "specificity": 0.13623188405797101,
        "precision": 0.6590389016018307,
        "positives": 605,
        "negatives": 345
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.61,
        "f1": 0.6587064676616915,
        "sensitivity": 0.547107438016529,
        "specificity": 0.8,
        "precision": 0.8275,
        "positives": 605,
        "negatives": 345
      }
    },
    "CD": {
      "best_f1": {
        "threshold": 0.52,
        "f1": 0.7172619047619048,
        "sensitivity": 0.7875816993464052,
        "specificity": 0.8059006211180124,
        "precision": 0.6584699453551912,
        "positives": 306,
        "negatives": 644
      },
      "best_youden": {
        "threshold": 0.52,
        "f1": 0.7172619047619048,
        "sensitivity": 0.7875816993464052,
        "specificity": 0.8059006211180124,
        "precision": 0.6584699453551912,
        "positives": 306,
        "negatives": 644
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.27228263229131694,
        "f1": 0.6823238566131026,
        "sensitivity": 0.9019607843137255,
        "specificity": 0.6475155279503105,
        "precision": 0.5487077534791253,
        "positives": 306,
        "negatives": 644
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.11145342856645582,
        "f1": 0.5878787878787879,
        "sensitivity": 0.9509803921568627,
        "specificity": 0.38975155279503104,
        "precision": 0.42543859649122806,
        "positives": 306,
        "negatives": 644
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.51,
        "f1": 0.7159763313609467,
        "sensitivity": 0.7908496732026143,
        "specificity": 0.8012422360248447,
        "precision": 0.654054054054054,
        "positives": 306,
        "negatives": 644
      }
    },
    "HYP": {
      "best_f1": {
        "threshold": 0.8200000000000001,
        "f1": 0.5128205128205128,
        "sensitivity": 0.48672566371681414,
        "specificity": 0.8715469613259669,
        "precision": 0.541871921182266,
        "positives": 226,
        "negatives": 724
      },
      "best_youden": {
        "threshold": 0.8200000000000001,
        "f1": 0.5128205128205128,
        "sensitivity": 0.48672566371681414,
        "specificity": 0.8715469613259669,
        "precision": 0.541871921182266,
        "positives": 226,
        "negatives": 724
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.1627185672521591,
        "f1": 0.4158215010141988,
        "sensitivity": 0.9070796460176991,
        "specificity": 0.23342541436464087,
        "precision": 0.26973684210526316,
        "positives": 226,
        "negatives": 724
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.0828499592840671,
        "f1": 0.3996299722479186,
        "sensitivity": 0.9557522123893806,
        "specificity": 0.11740331491712708,
        "precision": 0.25263157894736843,
        "positives": 226,
        "negatives": 724
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.7586179542541504,
        "f1": 0.4959349593495935,
        "sensitivity": 0.5398230088495575,
        "specificity": 0.8011049723756906,
        "precision": 0.45864661654135336,
        "positives": 226,
        "negatives": 724
      }
    }
  },
  "georgia": {
    "NORM": {
      "best_f1": {
        "threshold": 0.32,
        "f1": 0.6764275256222547,
        "sensitivity": 0.77,
        "specificity": 0.770739064856712,
        "precision": 0.6031331592689295,
        "positives": 300,
        "negatives": 663
      },
      "best_youden": {
        "threshold": 0.15,
        "f1": 0.6701030927835051,
        "sensitivity": 0.8666666666666667,
        "specificity": 0.6742081447963801,
        "precision": 0.5462184873949579,
        "positives": 300,
        "negatives": 663
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.06637051656842226,
        "f1": 0.6244239631336406,
        "sensitivity": 0.9033333333333333,
        "specificity": 0.5520361990950227,
        "precision": 0.477112676056338,
        "positives": 300,
        "negatives": 663
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.031954809725284555,
        "f1": 0.5968586387434555,
        "sensitivity": 0.95,
        "specificity": 0.4419306184012066,
        "precision": 0.4351145038167939,
        "positives": 300,
        "negatives": 663
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.4042208182811738,
        "f1": 0.6676970633693973,
        "sensitivity": 0.72,
        "specificity": 0.8024132730015083,
        "precision": 0.622478386167147,
        "positives": 300,
        "negatives": 663
      }
    },
    "MI": {
      "best_f1": {
        "threshold": 0.9862026572227477,
        "f1": 0.07407407407407407,
        "sensitivity": 0.14285714285714285,
        "specificity": 0.9801255230125523,
        "precision": 0.05,
        "positives": 7,
        "negatives": 956
      },
      "best_youden": {
        "threshold": 0.4673043072223663,
        "f1": 0.030612244897959183,
        "sensitivity": 0.8571428571428571,
        "specificity": 0.6035564853556485,
        "precision": 0.015584415584415584,
        "positives": 7,
        "negatives": 956
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.118293132930994,
        "f1": 0.020260492040520984,
        "sensitivity": 1.0,
        "specificity": 0.2918410041841004,
        "precision": 0.01023391812865497,
        "positives": 7,
        "negatives": 956
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.118293132930994,
        "f1": 0.020260492040520984,
        "sensitivity": 1.0,
        "specificity": 0.2918410041841004,
        "precision": 0.01023391812865497,
        "positives": 7,
        "negatives": 956
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.8084603071212769,
        "f1": 0.024844720496894408,
        "sensitivity": 0.2857142857142857,
        "specificity": 0.8410041841004184,
        "precision": 0.012987012987012988,
        "positives": 7,
        "negatives": 956
      }
    },
    "STTC": {
      "best_f1": {
        "threshold": 0.060000000000000005,
        "f1": 0.7525676937441643,
        "sensitivity": 0.9035874439461884,
        "specificity": 0.5705996131528046,
        "precision": 0.6448,
        "positives": 446,
        "negatives": 517
      },
      "best_youden": {
        "threshold": 0.26,
        "f1": 0.7295173961840629,
        "sensitivity": 0.7286995515695067,
        "specificity": 0.7678916827852998,
        "precision": 0.7303370786516854,
        "positives": 446,
        "negatives": 517
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.060000000000000005,
        "f1": 0.7525676937441643,
        "sensitivity": 0.9035874439461884,
        "specificity": 0.5705996131528046,
        "precision": 0.6448,
        "positives": 446,
        "negatives": 517
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.018078148588538078,
        "f1": 0.70843776106934,
        "sensitivity": 0.9506726457399103,
        "specificity": 0.36750483558994196,
        "precision": 0.5645805592543276,
        "positives": 446,
        "negatives": 517
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.34864605069160465,
        "f1": 0.7097532314923619,
        "sensitivity": 0.6771300448430493,
        "specificity": 0.8007736943907157,
        "precision": 0.745679012345679,
        "positives": 446,
        "negatives": 517
      }
    },
    "CD": {
      "best_f1": {
        "threshold": 0.2979473769664764,
        "f1": 0.5858585858585859,
        "sensitivity": 0.703030303030303,
        "specificity": 0.636650868878357,
        "precision": 0.5021645021645021,
        "positives": 330,
        "negatives": 633
      },
      "best_youden": {
        "threshold": 0.3473912698030472,
        "f1": 0.5833333333333334,
        "sensitivity": 0.6575757575757576,
        "specificity": 0.688783570300158,
        "precision": 0.5241545893719807,
        "positives": 330,
        "negatives": 633
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.09,
        "f1": 0.5585754451733833,
        "sensitivity": 0.9030303030303031,
        "specificity": 0.30647709320695105,
        "precision": 0.4043419267299864,
        "positives": 330,
        "negatives": 633
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.05052200183272356,
        "f1": 0.5487804878048781,
        "sensitivity": 0.9545454545454546,
        "specificity": 0.20537124802527645,
        "precision": 0.38508557457212717,
        "positives": 330,
        "negatives": 633
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.5700000000000001,
        "f1": 0.5504,
        "sensitivity": 0.5212121212121212,
        "specificity": 0.8056872037914692,
        "precision": 0.5830508474576271,
        "positives": 330,
        "negatives": 633
      }
    },
    "HYP": {
      "best_f1": {
        "threshold": 0.1637857019901275,
        "f1": 0.5448354143019296,
        "sensitivity": 0.7920792079207921,
        "specificity": 0.48787878787878786,
        "precision": 0.41522491349480967,
        "positives": 303,
        "negatives": 660
      },
      "best_youden": {
        "threshold": 0.19102255731821052,
        "f1": 0.5446009389671361,
        "sensitivity": 0.7656765676567657,
        "specificity": 0.5196969696969697,
        "precision": 0.4225865209471767,
        "positives": 303,
        "negatives": 660
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.0815571609139442,
        "f1": 0.5314009661835749,
        "sensitivity": 0.9075907590759076,
        "specificity": 0.30757575757575756,
        "precision": 0.3756830601092896,
        "positives": 303,
        "negatives": 660
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.051215041354298545,
        "f1": 0.5245009074410163,
        "sensitivity": 0.9537953795379538,
        "specificity": 0.22727272727272727,
        "precision": 0.3617021276595745,
        "positives": 303,
        "negatives": 660
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.53,
        "f1": 0.44165170556552963,
        "sensitivity": 0.40594059405940597,
        "specificity": 0.8015151515151515,
        "precision": 0.484251968503937,
        "positives": 303,
        "negatives": 660
      }
    }
  },
  "ptb": {
    "NORM": {
      "best_f1": {
        "threshold": 0.33,
        "f1": 0.770949720670391,
        "sensitivity": 0.8625,
        "specificity": 0.9104477611940298,
        "precision": 0.696969696969697,
        "positives": 80,
        "negatives": 335
      },
      "best_youden": {
        "threshold": 0.19,
        "f1": 0.7411167512690355,
        "sensitivity": 0.9125,
        "specificity": 0.8686567164179104,
        "precision": 0.6239316239316239,
        "positives": 80,
        "negatives": 335
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.2,
        "f1": 0.7461139896373057,
        "sensitivity": 0.9,
        "specificity": 0.8776119402985074,
        "precision": 0.6371681415929203,
        "positives": 80,
        "negatives": 335
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.13822624206542972,
        "f1": 0.7136150234741784,
        "sensitivity": 0.95,
        "specificity": 0.8298507462686567,
        "precision": 0.5714285714285714,
        "positives": 80,
        "negatives": 335
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.13822624206542972,
        "f1": 0.7136150234741784,
        "sensitivity": 0.95,
        "specificity": 0.8298507462686567,
        "precision": 0.5714285714285714,
        "positives": 80,
        "negatives": 335
      }
    },
    "MI": {
      "best_f1": {
        "threshold": 0.17,
        "f1": 0.8949044585987261,
        "sensitivity": 0.9273927392739274,
        "specificity": 0.6071428571428571,
        "precision": 0.8646153846153846,
        "positives": 303,
        "negatives": 112
      },
      "best_youden": {
        "threshold": 0.43,
        "f1": 0.8706293706293706,
        "sensitivity": 0.8217821782178217,
        "specificity": 0.8214285714285714,
        "precision": 0.9256505576208178,
        "positives": 303,
        "negatives": 112
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.24000000000000002,
        "f1": 0.8939641109298532,
        "sensitivity": 0.9042904290429042,
        "specificity": 0.6785714285714286,
        "precision": 0.8838709677419355,
        "positives": 303,
        "negatives": 112
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.12,
        "f1": 0.891640866873065,
        "sensitivity": 0.9504950495049505,
        "specificity": 0.5089285714285714,
        "precision": 0.8396501457725948,
        "positives": 303,
        "negatives": 112
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.41000000000000003,
        "f1": 0.8754325259515571,
        "sensitivity": 0.834983498349835,
        "specificity": 0.8035714285714286,
        "precision": 0.92,
        "positives": 303,
        "negatives": 112
      }
    },
    "STTC": {
      "best_f1": null,
      "best_youden": null,
      "best_sensitivity_90_with_max_specificity": null,
      "best_sensitivity_95_with_max_specificity": null,
      "best_specificity_80_with_max_sensitivity": null
    },
    "CD": {
      "best_f1": {
        "threshold": 0.9500000000000001,
        "f1": 0.5652173913043478,
        "sensitivity": 0.5909090909090909,
        "specificity": 0.9720101781170484,
        "precision": 0.5416666666666666,
        "positives": 22,
        "negatives": 393
      },
      "best_youden": {
        "threshold": 0.7375101804733276,
        "f1": 0.4470588235294118,
        "sensitivity": 0.8636363636363636,
        "specificity": 0.8880407124681934,
        "precision": 0.30158730158730157,
        "positives": 22,
        "negatives": 393
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.62,
        "f1": 0.36036036036036034,
        "sensitivity": 0.9090909090909091,
        "specificity": 0.8244274809160306,
        "precision": 0.2247191011235955,
        "positives": 22,
        "negatives": 393
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.51,
        "f1": 0.29577464788732394,
        "sensitivity": 0.9545454545454546,
        "specificity": 0.7480916030534351,
        "precision": 0.175,
        "positives": 22,
        "negatives": 393
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.62,
        "f1": 0.36036036036036034,
        "sensitivity": 0.9090909090909091,
        "specificity": 0.8244274809160306,
        "precision": 0.2247191011235955,
        "positives": 22,
        "negatives": 393
      }
    },
    "HYP": {
      "best_f1": {
        "threshold": 0.61,
        "f1": 0.5806451612903226,
        "sensitivity": 0.6923076923076923,
        "specificity": 0.9776119402985075,
        "precision": 0.5,
        "positives": 13,
        "negatives": 402
      },
      "best_youden": {
        "threshold": 0.31,
        "f1": 0.3384615384615385,
        "sensitivity": 0.8461538461538461,
        "specificity": 0.8980099502487562,
        "precision": 0.21153846153846154,
        "positives": 13,
        "negatives": 402
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.22,
        "f1": 0.24489795918367346,
        "sensitivity": 0.9230769230769231,
        "specificity": 0.818407960199005,
        "precision": 0.1411764705882353,
        "positives": 13,
        "negatives": 402
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.012630300652235648,
        "f1": 0.06516290726817042,
        "sensitivity": 1.0,
        "specificity": 0.07213930348258707,
        "precision": 0.03367875647668394,
        "positives": 13,
        "negatives": 402
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.22,
        "f1": 0.24489795918367346,
        "sensitivity": 0.9230769230769231,
        "specificity": 0.818407960199005,
        "precision": 0.1411764705882353,
        "positives": 13,
        "negatives": 402
      }
    }
  },
  "ALL_SOURCES_STACKED_REFERENCE_ONLY": {
    "NORM": {
      "best_f1": {
        "threshold": 0.73,
        "f1": 0.639511201629328,
        "sensitivity": 0.6906158357771262,
        "specificity": 0.8740157480314961,
        "precision": 0.595448798988622,
        "positives": 682,
        "negatives": 2540
      },
      "best_youden": {
        "threshold": 0.33,
        "f1": 0.6165966386554622,
        "sensitivity": 0.8607038123167156,
        "specificity": 0.75,
        "precision": 0.48036006546644844,
        "positives": 682,
        "negatives": 2540
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.2119502474367621,
        "f1": 0.5938104448742747,
        "sensitivity": 0.9002932551319648,
        "specificity": 0.6960629921259842,
        "precision": 0.443001443001443,
        "positives": 682,
        "negatives": 2540
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.07021381869912144,
        "f1": 0.5359207266721717,
        "sensitivity": 0.9516129032258065,
        "specificity": 0.5704724409448819,
        "precision": 0.37298850574712644,
        "positives": 682,
        "negatives": 2540
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.51,
        "f1": 0.6218097447795824,
        "sensitivity": 0.7859237536656891,
        "specificity": 0.8007874015748031,
        "precision": 0.5143953934740882,
        "positives": 682,
        "negatives": 2540
      }
    },
    "MI": {
      "best_f1": {
        "threshold": 0.62,
        "f1": 0.5984084880636604,
        "sensitivity": 0.7258687258687259,
        "specificity": 0.7775051124744377,
        "precision": 0.5090252707581228,
        "positives": 777,
        "negatives": 2445
      },
      "best_youden": {
        "threshold": 0.612034022808075,
        "f1": 0.5973753280839895,
        "sensitivity": 0.7323037323037324,
        "specificity": 0.7713701431492842,
        "precision": 0.5044326241134752,
        "positives": 777,
        "negatives": 2445
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.2358418753743172,
        "f1": 0.5298563869992441,
        "sensitivity": 0.9021879021879022,
        "specificity": 0.5222903885480572,
        "precision": 0.3750668806848582,
        "positives": 777,
        "negatives": 2445
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.12220472328364843,
        "f1": 0.49266666666666664,
        "sensitivity": 0.9510939510939511,
        "specificity": 0.39304703476482616,
        "precision": 0.3324336482231219,
        "positives": 777,
        "negatives": 2445
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.67,
        "f1": 0.5963149078726968,
        "sensitivity": 0.6872586872586872,
        "specificity": 0.803680981595092,
        "precision": 0.5266272189349113,
        "positives": 777,
        "negatives": 2445
      }
    },
    "STTC": {
      "best_f1": {
        "threshold": 0.09999999999999999,
        "f1": 0.67392,
        "sensitivity": 0.7794226498889711,
        "specificity": 0.6146445750935329,
        "precision": 0.5935738444193912,
        "positives": 1351,
        "negatives": 1871
      },
      "best_youden": {
        "threshold": 0.29000000000000004,
        "f1": 0.6595009596928982,
        "sensitivity": 0.6358253145817913,
        "specificity": 0.7888829502939605,
        "precision": 0.6850079744816587,
        "positives": 1351,
        "negatives": 1871
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.020262070298194875,
        "f1": 0.6543507362784471,
        "sensitivity": 0.9045151739452257,
        "specificity": 0.378941742383752,
        "precision": 0.5125838926174496,
        "positives": 1351,
        "negatives": 1871
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.006202280521392793,
        "f1": 0.6349519349272862,
        "sensitivity": 0.9533678756476683,
        "specificity": 0.242116515232496,
        "precision": 0.4759793052475979,
        "positives": 1351,
        "negatives": 1871
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.32,
        "f1": 0.6551724137931034,
        "sensitivity": 0.61880088823094,
        "specificity": 0.8049171566007483,
        "precision": 0.6960865945045795,
        "positives": 1351,
        "negatives": 1871
      }
    },
    "CD": {
      "best_f1": {
        "threshold": 0.62,
        "f1": 0.6701461377870563,
        "sensitivity": 0.6625386996904025,
        "specificity": 0.8646249445184199,
        "precision": 0.6779303062302007,
        "positives": 969,
        "negatives": 2253
      },
      "best_youden": {
        "threshold": 0.47000000000000003,
        "f1": 0.6672888474101727,
        "sensitivity": 0.737874097007224,
        "specificity": 0.796271637816245,
        "precision": 0.6090289608177172,
        "positives": 969,
        "negatives": 2253
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.16,
        "f1": 0.5908629441624366,
        "sensitivity": 0.9009287925696594,
        "specificity": 0.5059920106524634,
        "precision": 0.4395770392749245,
        "positives": 969,
        "negatives": 2253
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.06999999999999999,
        "f1": 0.5264059377676278,
        "sensitivity": 0.9514963880288958,
        "specificity": 0.28450954283177987,
        "precision": 0.3638516179952644,
        "positives": 969,
        "negatives": 2253
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.48000000000000004,
        "f1": 0.6676069581570286,
        "sensitivity": 0.7327141382868937,
        "specificity": 0.8011540168664003,
        "precision": 0.613126079447323,
        "positives": 969,
        "negatives": 2253
      }
    },
    "HYP": {
      "best_f1": {
        "threshold": 0.62,
        "f1": 0.39067055393586003,
        "sensitivity": 0.4944649446494465,
        "specificity": 0.7902985074626866,
        "precision": 0.3228915662650602,
        "positives": 542,
        "negatives": 2680
      },
      "best_youden": {
        "threshold": 0.38,
        "f1": 0.3809024134312697,
        "sensitivity": 0.6697416974169742,
        "specificity": 0.6264925373134328,
        "precision": 0.2661290322580645,
        "positives": 542,
        "negatives": 2680
      },
      "best_sensitivity_90_with_max_specificity": {
        "threshold": 0.09999999999999999,
        "f1": 0.34504567814476456,
        "sensitivity": 0.9059040590405905,
        "specificity": 0.32350746268656716,
        "precision": 0.2131076388888889,
        "positives": 542,
        "negatives": 2680
      },
      "best_sensitivity_95_with_max_specificity": {
        "threshold": 0.05966176390647884,
        "f1": 0.3302340493747996,
        "sensitivity": 0.9501845018450185,
        "specificity": 0.23059701492537313,
        "precision": 0.19984478075281334,
        "positives": 542,
        "negatives": 2680
      },
      "best_specificity_80_with_max_sensitivity": {
        "threshold": 0.64,
        "f1": 0.3851963746223565,
        "sensitivity": 0.470479704797048,
        "specificity": 0.8033582089552239,
        "precision": 0.32608695652173914,
        "positives": 542,
        "negatives": 2680
      }
    }
  }
}