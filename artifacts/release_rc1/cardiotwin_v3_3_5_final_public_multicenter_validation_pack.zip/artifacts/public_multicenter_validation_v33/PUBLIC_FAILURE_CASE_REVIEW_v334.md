# CardioTwin-AI v3.3.4 Public Failure-case Review

Created: 2026-05-24T21:17:59.148807+00:00

## Purpose

Identify false positives, false negatives, high-confidence errors, low-SQI cases, and source-shift candidates after public source-separated validation.

## Failure Summary

{
  "total_prediction_rows": 3222,
  "total_failure_events": 6020,
  "failure_events_by_type": {
    "false_positive": 5302,
    "false_negative": 718
  },
  "failure_events_by_label": {
    "HYP": 1864,
    "CD": 1344,
    "STTC": 972,
    "NORM": 947,
    "MI": 893
  },
  "failure_events_by_source": {
    "cpsc_2018_extra": 1846,
    "georgia": 1784,
    "cpsc_2018": 1631,
    "ptb": 759
  },
  "failure_events_by_source_label": {
    "cpsc_2018::CD": {
      "events": 222,
      "false_positive": 208,
      "false_negative": 14,
      "mean_probability": 0.3435412651297074,
      "mean_sqi": 0.8146647221920169
    },
    "cpsc_2018::HYP": {
      "events": 612,
      "false_positive": 612,
      "false_negative": 0,
      "mean_probability": 0.47077183004200845,
      "mean_sqi": 0.8081042611412022
    },
    "cpsc_2018::MI": {
      "events": 177,
      "false_positive": 177,
      "false_negative": 0,
      "mean_probability": 0.7647796185676661,
      "mean_sqi": 0.8171323408987051
    },
    "cpsc_2018::NORM": {
      "events": 342,
      "false_positive": 337,
      "false_negative": 5,
      "mean_probability": 0.6567475786922794,
      "mean_sqi": 0.8083575883760916
    },
    "cpsc_2018::STTC": {
      "events": 278,
      "false_positive": 128,
      "false_negative": 150,
      "mean_probability": 0.24126331319267402,
      "mean_sqi": 0.8076401207575618
    },
    "cpsc_2018_extra::CD": {
      "events": 385,
      "false_positive": 367,
      "false_negative": 18,
      "mean_probability": 0.4242571686506829,
      "mean_sqi": 0.8215984835833265
    },
    "cpsc_2018_extra::HYP": {
      "events": 634,
      "false_positive": 622,
      "false_negative": 12,
      "mean_probability": 0.5089335556465938,
      "mean_sqi": 0.8132131530807442
    },
    "cpsc_2018_extra::MI": {
      "events": 270,
      "false_positive": 169,
      "false_negative": 101,
      "mean_probability": 0.5575929394006919,
      "mean_sqi": 0.8138685208975612
    },
    "cpsc_2018_extra::NORM": {
      "events": 270,
      "false_positive": 270,
      "false_negative": 0,
      "mean_probability": 0.5169545521890676,
      "mean_sqi": 0.808364342050292
    },
    "cpsc_2018_extra::STTC": {
      "events": 287,
      "false_positive": 156,
      "false_negative": 131,
      "mean_probability": 0.3250960415507158,
      "mean_sqi": 0.8146013280073096
    },
    "georgia::CD": {
      "events": 434,
      "false_positive": 384,
      "false_negative": 50,
      "mean_probability": 0.41650757045927134,
      "mean_sqi": 0.8358428328497333
    },
    "georgia::HYP": {
      "events": 464,
      "false_positive": 426,
      "false_negative": 38,
      "mean_probability": 0.3879643302412848,
      "mean_sqi": 0.8370904035079263
    },
    "georgia::MI": {
      "events": 363,
      "false_positive": 360,
      "false_negative": 3,
      "mean_probability": 0.7564523796609939,
      "mean_sqi": 0.8400242889525501
    },
    "georgia::NORM": {
      "events": 268,
      "false_positive": 229,
      "false_negative": 39,
      "mean_probability": 0.4515710591074468,
      "mean_sqi": 0.8320738525853599
    },
    "georgia::STTC": {
      "events": 255,
      "false_positive": 167,
      "false_negative": 88,
      "mean_probability": 0.3314072417894803,
      "mean_sqi": 0.8356432938008385
    },
    "ptb::CD": {
      "events": 303,
      "false_positive": 303,
      "false_negative": 0,
      "mean_probability": 0.4349825088143742,
      "mean_sqi": 0.8836717269247981
    },
    "ptb::HYP": {
      "events": 154,
      "false_positive": 153,
      "false_negative": 1,
      "mean_probability": 0.2643123047801291,
      "mean_sqi": 0.8764826482146659
    },
    "ptb::MI": {
      "events": 83,
      "false_positive": 19,
      "false_negative": 64,
      "mean_probability": 0.36786688407546425,
      "mean_sqi": 0.8858090055975398
    },
    "ptb::NORM": {
      "events": 67,
      "false_positive": 63,
      "false_negative": 4,
      "mean_probability": 0.407193430657707,
      "mean_sqi": 0.8747572335566637
    },
    "ptb::STTC": {
      "events": 152,
      "false_positive": 152,
      "false_negative": 0,
      "mean_probability": 0.37905123339671837,
      "mean_sqi": 0.8837927882586759
    }
  },
  "low_sqi_failure_events": 2,
  "high_confidence_false_positive_events": 1097,
  "low_model_score_false_negative_events": 616
}

## Recommended Actions

- Review top false positives and false negatives by source and label before any clinical claim.
- Prioritize doctor review for high-confidence false positives and low-score false negatives.
- Treat rare-label source results cautiously, especially source-label pairs with fewer than 30 positives.
- Use v3.3.3 threshold stress as analytical guidance only; do not overwrite frozen runtime thresholds yet.
- Add prospective doctor-in-the-loop adjudication before clinical deployment claims.

## Outputs

- artifacts\public_multicenter_validation_v33\public_failure_cases_v334.csv
- artifacts\public_multicenter_validation_v33\public_top_failure_cases_for_review_v334.csv
- artifacts\public_multicenter_validation_v33\doctor_in_the_loop_review_template_v334.csv
- artifacts\public_multicenter_validation_v33\public_failure_case_review_summary_v334.json

## Claim Boundary

Failure-case review and doctor-review preparation only. Not clinical diagnosis and not prospective validation.