# CardioTwin-AI v3.3.2 Public Per-source Metrics Summary

Created: 2026-05-24T21:12:38.517684+00:00

## Scope

Metrics were computed from frozen v3.3.1 predictions on the locked v3.3.0 public cohort.

## Source-level macro summary

### ALL_SOURCES_STACKED_REFERENCE_ONLY

- macro_auroc: 0.8090379398203323
- macro_auprc: 0.6308889859483346
- macro_f1: 0.546475139623044
- macro_sensitivity: 0.8523104548151496
- macro_specificity: 0.5581234715637216
- macro_precision: 0.4231012041933555
- labels_with_valid_auroc: 5

### cpsc_2018

- macro_auroc: 0.8394086059577441
- macro_auprc: 0.7289478643190268
- macro_f1: 0.3760039057279059
- macro_sensitivity: 0.4876634512325831
- macro_specificity: 0.5955692162859442
- macro_precision: 0.31889186182073265
- labels_with_valid_auroc: 3

### cpsc_2018_extra

- macro_auroc: 0.8076029136993542
- macro_auprc: 0.5908221705450434
- macro_f1: 0.5030275262744933
- macro_sensitivity: 0.8910552219799796
- macro_specificity: 0.49682553630920345
- macro_precision: 0.4279043121645404
- labels_with_valid_auroc: 5

### georgia

- macro_auroc: 0.7546458500979961
- macro_auprc: 0.5305637682299218
- macro_f1: 0.5032572905823809
- macro_sensitivity: 0.7934382923237872
- macro_specificity: 0.5405848478667675
- macro_precision: 0.4061471503746438
- labels_with_valid_auroc: 5

### ptb

- macro_auroc: 0.9163566007649272
- macro_auprc: 0.7194344542314709
- macro_f1: 0.3615492902451978
- macro_sensitivity: 0.7323711601929423
- macro_specificity: 0.624888599957211
- macro_precision: 0.322707751898985
- labels_with_valid_auroc: 4

## Boundary

Source-separated metrics only. Not prospective clinical validation. Do not claim doctor-level diagnosis.