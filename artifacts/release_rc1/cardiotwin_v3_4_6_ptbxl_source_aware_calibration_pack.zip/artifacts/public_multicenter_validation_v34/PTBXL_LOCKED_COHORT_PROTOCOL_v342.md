# CardioTwin-AI v3.4.2 PTB-XL Locked Cohort Protocol

Created: 2026-05-31T11:07:11.373899+00:00

## Purpose

Build PTB-XL source-controlled cohorts for v3.4 source-aware calibration and locked evaluation.

## Cohorts

- Fold 9 calibration cohort: 2146 records
- Fold 10 locked evaluation cohort: 2158 records
- Fold 10 balanced smoke subset: 235 records

## Fold 9 Calibration Label Counts

- NORM: 955
- MI: 540
- STTC: 528
- CD: 495
- HYP: 268

## Fold 10 Locked Evaluation Label Counts

- NORM: 963
- MI: 550
- STTC: 521
- CD: 496
- HYP: 262

## Rules

- Use fold 9 only for calibration/threshold analysis.
- Use fold 10 as locked evaluation cohort.
- Do not train or tune the model on fold 10.
- Do not modify v3.3.5 frozen evidence.
- Report PTB-XL as source-controlled benchmark if PTB-XL influenced earlier model development.
- Do not claim PTB-XL as fully unseen external hospital validation unless provenance confirms no development exposure.

## Claim Boundary

PTB-XL v3.4.2 cohorts are for source-controlled benchmark and source-aware calibration only. Not clinical deployment and not prospective validation.