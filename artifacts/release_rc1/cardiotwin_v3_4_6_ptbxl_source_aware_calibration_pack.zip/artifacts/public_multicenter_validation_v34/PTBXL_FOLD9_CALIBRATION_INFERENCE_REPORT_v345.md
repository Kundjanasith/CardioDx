# CardioTwin-AI v3.4.5 PTB-XL Fold 9 Calibration Inference Report

Created: 2026-05-31T11:25:38.442645+00:00

## Status

- Records requested: 2146
- OK count: 2146
- Error count: 0
- Status: pass

## Runtime Bridge

- Module: cardiotwin.runtime.v304_real_inference_bridge
- Callable: wfdb.rdsamp + run_v304_real_inference

## Runtime

- Total wall time seconds: 238.39
- Mean per-record seconds: 0.1107

## Claim Boundary

PTB-XL fold 9 calibration inference only. Thresholds derived here are evaluated on fold 10 in the next step.