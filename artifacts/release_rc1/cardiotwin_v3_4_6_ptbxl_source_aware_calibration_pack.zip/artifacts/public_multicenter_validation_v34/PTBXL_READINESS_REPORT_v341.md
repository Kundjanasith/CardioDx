# CardioTwin-AI v3.4.1 PTB-XL Standalone Readiness Report

Created: 2026-05-31T11:04:58.624973+00:00

## Status

- Readiness: ready_candidate
- Metadata rows: 21799
- HR waveform-ready rows: 21799
- LR waveform-ready rows: 21799
- Label-mapped rows: 21388

## Label Counts

- NORM: 9514
- MI: 5469
- STTC: 5235
- CD: 4898
- HYP: 2649

## Intended Use

PTB-XL standalone should be used as an official/source-controlled benchmark and calibration dataset.

## Claim Boundary

PTB-XL standalone is a source-controlled benchmark. If PTB-XL influenced model development, do not claim it as fully unseen external validation.