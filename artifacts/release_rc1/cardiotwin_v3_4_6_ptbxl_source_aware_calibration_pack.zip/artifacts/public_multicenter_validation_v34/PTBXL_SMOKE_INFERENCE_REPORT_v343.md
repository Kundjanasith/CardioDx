# CardioTwin-AI v3.4.3 PTB-XL Smoke Locked Inference Report

Created: 2026-05-31T11:13:40.637526+00:00

## Status

- Records requested: 235
- OK count: 235
- Error count: 0
- Status: pass

## Runtime Bridge

- Module: cardiotwin.runtime.v304_real_inference_bridge
- Callable: wfdb.rdsamp + run_v304_real_inference

## Runtime

- Total wall time seconds: 61.15
- Mean per-record seconds: 0.2598

## Claim Boundary

PTB-XL smoke inference is runtime compatibility testing only. Not final PTB-XL metric validation.