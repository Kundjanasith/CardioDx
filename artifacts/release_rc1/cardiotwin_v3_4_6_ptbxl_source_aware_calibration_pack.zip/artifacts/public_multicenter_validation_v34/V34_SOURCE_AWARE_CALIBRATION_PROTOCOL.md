# CardioTwin-AI v3.4 Source-aware Calibration Protocol

Created: 2026-05-31T11:00:20.859132+00:00

## Purpose

v3.4 expands the frozen v3.3.5 public validation release by adding more public ECG sources and analyzing source-aware calibration behavior.

## Frozen Baseline

v3.3.5 remains the final public validation release and must not be modified.

## Planned Added Sources

- PTB-XL standalone official split
- Chapman-Shaoxing
- Ningbo
- INCART as special stress test

## Rules

- Use frozen CardioTwin-AI runtime.
- Do not retrain the model in v3.4.
- Keep source-separated reporting.
- Do not pool datasets as random split.
- Keep raw ECG datasets outside GitHub.
- Treat INCART as long-record / arrhythmia / signal stress test, not as the same type as 10-second diagnostic ECG.

## v3.4 Work Plan

1. v3.4.0 scaffold and inventory
2. v3.4.1 expanded dataset readiness audit
3. v3.4.2 label harmonization audit
4. v3.4.3 locked inference on added sources
5. v3.4.4 source-aware calibration
6. v3.4.5 failure-case review addendum
7. v3.4.6 expanded public validation addendum pack

## Claim Boundary

v3.4 is expanded public validation and calibration analysis only. It is not clinical deployment, not prospective validation, and not final diagnosis.
