# CardioTwin-AI v3.4.4 PTB-XL Fold 10 Locked Evaluation Inference Report

Created: 2026-05-31T11:16:58.945862+00:00

## Status

- Records requested: 2158
- OK count: 2158
- Error count: 0
- Status: pass

## Runtime Bridge

- Module: cardiotwin.runtime.v304_real_inference_bridge
- Callable: wfdb.rdsamp + run_v304_real_inference

## Runtime

- Total wall time seconds: 239.13
- Mean per-record seconds: 0.1104

## Claim Boundary

PTB-XL fold 10 locked inference only. Metrics and calibration are computed in the next step.